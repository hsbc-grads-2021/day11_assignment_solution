package com.hsbc.FlightInformationSystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Duration;
import java.time.LocalTime;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hsbc.FlightInformationSystem.entity.FlightInformation;

/**
 * @author Rajesh Upadhyay
 *this class is used to get information about flight from database and return to service caller.
 */

@Repository
public class FlightInformationSystemDAO implements FlightInformationSystemDAOInterface {

	@Autowired
	private DataSource ds;
	
	


//this method is used to fetch information from database using data source

	@Override
	public FlightInformation distanceDAO(FlightInformation flightInformation) {
		FlightInformation flightInformation1=null;
		try {
			Connection con=ds.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from FlightInformation where From_city=? and To_City=?");
			ps.setString(1,flightInformation.getFrom_city() );
			ps.setString(2, flightInformation.getTo_City());
			
			ResultSet res=ps.executeQuery();
			if(res.next()) {
				flightInformation1=new FlightInformation();
				LocalTime t1=LocalTime.parse(res.getString("start_time"));
				LocalTime t2=LocalTime.parse(res.getString("end_time"));
				
				flightInformation1.setStart_time(t1);
				flightInformation1.setEnd_time(t2);
				
				flightInformation1.setDistance(res.getDouble("distance"));
			
			}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		return flightInformation1;
	}

	
}
