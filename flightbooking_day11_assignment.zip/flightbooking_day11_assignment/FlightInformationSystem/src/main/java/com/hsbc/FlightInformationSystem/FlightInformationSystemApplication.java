package com.hsbc.FlightInformationSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Rajesh Upadhyay
 *Main class
 */
@SpringBootApplication
public class FlightInformationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightInformationSystemApplication.class, args);
	}

}
