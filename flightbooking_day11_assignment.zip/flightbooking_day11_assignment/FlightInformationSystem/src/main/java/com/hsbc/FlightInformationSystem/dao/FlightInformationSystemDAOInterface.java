package com.hsbc.FlightInformationSystem.dao;

import com.hsbc.FlightInformationSystem.entity.FlightInformation;

/**
 * @author Rajesh Upadhyay
 *this is dao interface.
 */
public interface FlightInformationSystemDAOInterface {

	FlightInformation distanceDAO(FlightInformation flightInformation);



}
