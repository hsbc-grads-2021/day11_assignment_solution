package com.hsbc.FlightInformationSystem.entity;

import java.time.LocalTime;

/**
 * @author Rajesh Upadhyay
 *this class is main entity class used to transfer data from laye to layer
 */
public class FlightInformation {
	private long Flight_id;
	private String From_city; 
	private String To_City;
	private LocalTime start_time;
	private LocalTime end_time;
	private double distance;
	
	@Override
	public String toString() {
		return "FlightInformation [Flight_id=" + Flight_id + ", From_city=" + From_city + ", To_City=" + To_City
				+ ", start_time=" + start_time + ", end_time=" + end_time + ", distance=" + distance + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (Flight_id ^ (Flight_id >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FlightInformation other = (FlightInformation) obj;
		if (Flight_id != other.Flight_id)
			return false;
		return true;
	}
	public long getFlight_id() {
		return Flight_id;
	}
	public void setFlight_id(long flight_id) {
		Flight_id = flight_id;
	}
	public String getFrom_city() {
		return From_city;
	}
	public void setFrom_city(String from_city) {
		From_city = from_city;
	}
	public String getTo_City() {
		return To_City;
	}
	public void setTo_City(String to_City) {
		To_City = to_City;
	}
	public LocalTime getStart_time() {
		return start_time;
	}
	public void setStart_time(LocalTime start_time) {
		this.start_time = start_time;
	}
	public LocalTime getEnd_time() {
		return end_time;
	}
	public void setEnd_time(LocalTime end_time) {
		this.end_time = end_time;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	
	
}
