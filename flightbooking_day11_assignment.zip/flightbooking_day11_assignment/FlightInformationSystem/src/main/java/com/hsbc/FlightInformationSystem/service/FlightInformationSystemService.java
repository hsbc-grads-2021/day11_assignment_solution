package com.hsbc.FlightInformationSystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hsbc.FlightInformationSystem.dao.FlightInformationSystemDAOInterface;

import com.hsbc.FlightInformationSystem.entity.FlightInformation;

/**
 * @author Rajesh Upadhyay
 *this class is used to get information from controller and passed to dao and vice versa.
 */

@Service
public class FlightInformationSystemService implements FlightInformationSystemServiceInterface {
	//injecting dao;
	@Autowired
	private FlightInformationSystemDAOInterface md;

	@Override
	public FlightInformation distanceService(FlightInformation flightInformation) {
		// TODO Auto-generated method stub
		return md.distanceDAO(flightInformation);
	}

	
}
