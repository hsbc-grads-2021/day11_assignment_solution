package com.hsbc.FlightInformationSystem.service;

import com.hsbc.FlightInformationSystem.entity.FlightInformation;


/**
 * @author Rajesh Upadhyay
 *this is interface.
 */
public interface FlightInformationSystemServiceInterface {

	FlightInformation distanceService(FlightInformation flightInformation);

	
}
