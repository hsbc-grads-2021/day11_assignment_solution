package com.hsbc.FlightInformationSystem.controller;

import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hsbc.FlightInformationSystem.entity.FlightInformation;
import com.hsbc.FlightInformationSystem.service.FlightInformationSystemServiceInterface;




/**
 * @author Rajesh Upadhyay
 *this class is used to get information about flight from database and return to service caller.
 */
@RestController
public class FlightInformationSystemController {
	//injecting service to this layer
	@Autowired
	private FlightInformationSystemServiceInterface ms;

	//this method is used to return flight information depends on user input from city and to city
	@GetMapping("distanceInformation/{fromcity}/{tocity}")
	public Map<String,String> getDistanceInformation(@PathVariable("fromcity") String fromcity,@PathVariable("tocity") String tocity){
		
		FlightInformation flightInformation=new FlightInformation();
		flightInformation.setFrom_city(fromcity);
		flightInformation.setTo_City(tocity);
		
		FlightInformation flight=ms.distanceService(flightInformation);
		
		// Calculating the difference in Minutes
		long hours = ChronoUnit.HOURS.between(flight.getStart_time(),flight.getEnd_time());
		
		  
        // Calculating the difference in Minutes
        long minutes
            = ChronoUnit.MINUTES.between(flight.getStart_time(),flight.getEnd_time()) % 60;
  
        // Calculating the difference in Seconds
        long seconds
            = ChronoUnit.SECONDS.between(flight.getStart_time(),flight.getEnd_time()) % 60;
      
        String duration= hours + " hours " + minutes
                + " minutes " + seconds + " seconds.";
        Map<String, String> m=new HashMap<String, String>();
        m.put("distance", ""+flight.getDistance());
        m.put("duration", duration);
		return m;
		
	}
}
