package com.hsbc.FlightBooking.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.json.*;

/**
 * @author Rajesh Upadhyay
 *   this class is main controller class used to take request from end client and give response to client
 */

@Controller
public class MyAppController {
	
	//this method is used to take flight detail from client and passing detail to flightservice taking response and passing response to price service 
	@RequestMapping("createDetails")
	public ModelAndView register(@RequestParam("fromstation") String fromcity,@RequestParam("tostation") String tocity,@RequestParam("date") String date,@RequestParam("holidays") String holidays) {
		 LocalDate ll=null;
		try {
		   // String startDateString = "08-12-2017";
			//System.out.println(LocalDate.now());
		    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		    SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");
		   ll=LocalDate.parse(sdf.format(sdf2.parse(date)));
		} catch (ParseException e) {
		    e.printStackTrace();
		}
		
		DayOfWeek day=ll.getDayOfWeek();
		double ss1=0;
		String dd=null;
		String dd1=null;
		String dayofweek="no";
		if(day.toString().equalsIgnoreCase("saturday")||day.toString().equalsIgnoreCase("sunday")) {
			dayofweek="yes";
		}
		
		String baseUrl="http://localhost:8080/distanceInformation/"+fromcity+"/"+tocity;
		
		RestTemplate restTemplate = new RestTemplate();
		
		ResponseEntity<String> response=null;
		ResponseEntity<Double> response1=null;
		try{
		response=restTemplate.exchange(baseUrl,	HttpMethod.GET, getHeaders(),String.class);
		
		String ss= response.getBody();
		System.out.println(ss);
		
		ObjectMapper mapper = new ObjectMapper();
		JsonFactory factory = mapper.getFactory();
		JsonParser jsonParser = factory.createParser(ss);
		JsonNode node = mapper.readTree(jsonParser);
		
		 dd=(node.get("duration").toString()).substring(1, 2);
		 dd1=node.get("distance").toString().substring(1,5);
		
		String baseUrl1="http://localhost:10000/calculatePrice/"+dd1+"/"+day+"/"+holidays+"/"+dd;
		
		response1=restTemplate.exchange(baseUrl1,	HttpMethod.GET, getHeaders(),Double.class);
		
		ss1= response1.getBody();
		
		System.out.println(ss1);
		}catch (Exception ex)
		{
			System.out.println(ex);
		}
		
		
		/*JSONArray array = new JSONArray(ss);   
		 
		JSONObject object = array.getJSONObject(0);  
		System.out.println(object.getString("No"));  
		System.out.println(object.getString("Name"));  
		*/
		
		
		
		
		ModelAndView mv=new ModelAndView();
		mv.addObject("from",fromcity );
		mv.addObject("to", tocity);
		mv.addObject("duration",dd );
		mv.addObject("distance",dd1 );
		mv.addObject("dayofjourney", day);
		mv.addObject("weekends",dayofweek );
		mv.addObject("holidays",holidays );
		mv.addObject("price", ss1);
		mv.addObject("dateofjourney", date);
		
		mv.addObject("p1", "Flight Detail is below");
		
		
		mv.setViewName("register.jsp");
		
		return mv;
	}
	
	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
	
	
	
}
