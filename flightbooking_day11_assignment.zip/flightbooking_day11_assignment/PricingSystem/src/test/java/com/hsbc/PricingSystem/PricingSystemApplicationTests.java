package com.hsbc.PricingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PricingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
