package com.hsbc.PricingSystem.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Rajesh Upadhyay
 *this is pricing controller used to calculate price for flight
 */
@RestController
public class PricingController {
	
	//this method is use to calculate price for flight
	@GetMapping("calculatePrice/{distance}/{day}/{holidays}/{duration}")
	public double calculatePrice(@PathVariable("distance") long distance,@PathVariable("day") String weekends ,@PathVariable("holidays") String holidays,@PathVariable("duration") long duration) {
		double price=0.0d;
		System.out.println(distance+"  "+weekends+"   "+holidays+"  "+duration);
		if(distance>2000) {
			if(weekends .equalsIgnoreCase("Saturday")|| weekends .equalsIgnoreCase("Sunday")) {
				if(holidays.equalsIgnoreCase("yes")) {
					if(duration>2) {
						price=distance*19;
					}
					else {
						price=distance*18;
					}
				}
				else {
					if(duration>2) {
						price=distance*16;
					}
					else {
						price=distance*15;
					}
				
				}
				
			}
			else {
				price=distance*13;
			}
			
		}
			
		else {
			if(weekends .equalsIgnoreCase("Saturday")|| weekends .equalsIgnoreCase("Sunday")) {
				if(holidays.equalsIgnoreCase("yes")) {
					if(duration>2) {
						price=distance*23;
					}
					else {
						price=distance*22;
					}
				}
				else {
					if(duration>2) {
						price=distance*24;
					}
					else {
						price=distance*25;
					}
				
				}
				
			}
			else {
				price=distance*13;
			}
		}
		return price;
		
	}
}
